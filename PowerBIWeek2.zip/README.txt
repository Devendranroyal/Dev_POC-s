Download Power BI Desktop for free:
	- https://powerbi.microsoft.com/en-us/desktop/

Please, don't worry if you don't understand the database and the materials, or if you don't khow to use Power BI yet. 

This is the goal of Power BI Week.

So, be patient and do not ask questions before the event, as I will cover everything starting on Monday.

See you there!