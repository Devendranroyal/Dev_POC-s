import cv2
import numpy as np
from pykafka import KafkaClient
from pykafka.common import OffsetType

# client = KafkaClient(hosts='2.tcp.ngrok.io:13506')
client = KafkaClient(hosts='2.tcp.ngrok.io:12218')


def send_webcam_images_P(img):
    topic = client.topics['images']
    producer = topic.get_producer()
    producer.produce(img.tobytes())


def get_profile_C():
    consumer = client.topics['test'].get_simple_consumer(
        auto_offset_reset=OffsetType.LATEST, reset_offset_on_start=True)
    latest_offsets = [
           (partition, -2) for partition in consumer._partitions.keys()
        ]
    consumer.reset_offsets(latest_offsets)
    return consumer.consume().value.decode()

def fr_recognizer():
    cap = cv2.VideoCapture(0)
    face_cascade = cv2.CascadeClassifier(
        cv2.data.haarcascades + 'haarcascade_frontalface_alt.xml')
    
    # t1.start()
    while True:
        ret, frame = cap.read()
        if ret == False:
            return
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # print(gray.shape)
        faces = face_cascade.detectMultiScale(frame, 1.3, 5)
        if len(faces) > 0:
            for face in faces:
                 x, y, w, h = face
                 cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 255, 0), 2)
                 offset = 10
                 face_section = gray[y-offset:y+h+offset, x-offset:x+w+offset]
                #  face_section = cv2.resize(face_section, (100, 100))
                 new_img=cv2.resize(face_section,(100,100))
                #  print(new_img.shape)
                 send_webcam_images_P(new_img)
                 profile=get_profile_C()
                #  print(profile)
                 cv2.putText(frame,profile, (x,y), cv2.FONT_HERSHEY_SIMPLEX ,1, (0,0,255), 2)
            cv2.imshow("face", frame)
            
            # print(new_img.shape)
        key_pressed = cv2.waitKey(1) & 0xFF
        if key_pressed == ord('q'):
            break 
    cap.release()
    cv2.destroyAllWindows()



fr_recognizer()
