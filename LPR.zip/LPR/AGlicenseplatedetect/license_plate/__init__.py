__author__ = 'adrianrosebrock'

# import the necessary packages
from .license_plate import LicensePlateDetector
