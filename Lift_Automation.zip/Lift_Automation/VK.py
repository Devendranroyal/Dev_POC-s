# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'VK.ui'
#
# Created by: PyQt5 UI code generator 5.11.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import cv2
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication
import numpy as np
from PIL import Image
import os
import numpy as np
import pickle
import time
import pyautogui as gui
import sys
import numpy as np
#import Lift2
#from lift import Ui_MainWindow 

import cv2
import math
#import pyautogui
#pyautogui.size()
#width, height= pyautogui.size()


class Ui_MainWindow(object):
    
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1366, 768)
        
        MainWindow.setStyleSheet("background-color:#363b40;")
        
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(300, 70, 781, 541))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_2.setObjectName("label_2")
        self.verticalLayout.addWidget(self.label_2)
        self.label_2.setFixedSize(1250,350)
        self.label_2.setStyleSheet('QLabel {font-size : 30px;color:white;}')
        self.pushButton = QtWidgets.QPushButton(self.verticalLayoutWidget)
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout.addWidget(self.pushButton)
        self.pushButton.setText("Start")
        self.pushButton.setStyleSheet("""QPushButton { background-color: #4CAF50; border: none;
      color: white;
      padding: 10px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 20px;}""")

        self.pushButton2 = QtWidgets.QPushButton(self.verticalLayoutWidget)
        self.pushButton2.setObjectName("pushButton2")
        self.verticalLayout.addWidget(self.pushButton2)
        self.pushButton2.setText("Stop And Exit")
        self.pushButton2.setStyleSheet("""QPushButton { background-color: #4CAF50; border: none;
      color: white;
      padding: 10px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 20px;}""")
        
        self.pushButton3 = QtWidgets.QPushButton(self.verticalLayoutWidget)
        self.pushButton3.setObjectName("pushButton3")
        self.verticalLayout.addWidget(self.pushButton3)
        self.pushButton3.setText("Back")
        self.pushButton3.setStyleSheet("""QPushButton { background-color: #4CAF50; border: none;
      color: white;
      padding: 10px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 20px;}""")
        
        

        self.label = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label.setObjectName("label")
        self.label.setStyleSheet('QLabel {font-size : 30px;color:white;}')

        self.verticalLayout.addWidget(self.label)
        self.lineEdit = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit.setStyleSheet("""QLineEdit
        {
     font-size:20pt;
     height:40px;
     width:150px;
     color:white
    }""")
        
        
        
        self.verticalLayout.addWidget(self.lineEdit)
        
        self.pushButton4 = QtWidgets.QPushButton(self.verticalLayoutWidget)
        self.pushButton4.setObjectName("pushButton4")
        self.verticalLayout.addWidget(self.pushButton4)
        self.pushButton4.setText("Reset")
        self.pushButton4.setStyleSheet("""QPushButton { background-color: #4CAF50; border: none;
      color: white;
      padding: 10px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 20px;}""")
        
        
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.cam = QtCore.QObject()
        self.cam = cv2.VideoCapture(0)

        with open("range.pickle", "rb") as f:       # range.pickle is generated by range-detector.py
            self.t = pickle.load(f)
        #self.cam = cv2.VideoCapture(0)
        '''if self.cam.read()[0]==False:
                                    self.cam=cv2.VideoCapture(0)'''
        self.hsv_lower = np.array([self.t[0], self.t[1], self.t[2]])    
        self.hsv_upper = np.array([self.t[3], self.t[4], self.t[5]])
        self.width = self.cam.get(cv2.CAP_PROP_FRAME_WIDTH)   # width of video captured by the webcam
        self.height = self.cam.get(cv2.CAP_PROP_FRAME_HEIGHT)

        self.pushButton.clicked.connect(self.virtual )
        self.pushButton2.clicked.connect(self.destroy)
        self.pushButton3.clicked.connect(self.Back)
        self.pushButton4.clicked.connect(self.virtual)
        self.pushButton3.clicked.connect(MainWindow.close)
        
        
    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_2.setText(_translate("MainWindow", "VIRTUAL KEYBOARD"))
        self.label.setText(_translate("MainWindow", "FLOOR NUMBER"))

    def destroy(self):
        self.cam.release()
        cv2.destroyAllWindows()
        sys.exit(0)

    def Back(self):
        from lift import Ui_MainWindow1 as liftWindow
        self.window = QtWidgets.QMainWindow()
        self.ui = liftWindow()
        self.ui.setupUi(self.window)
        self.window.show()
        #MainWindow.hide()
        #self.window.hide()
              
            
    def virtual(self):      
            cap = cv2.VideoCapture(0)
            width, height = 1920,1080
            cap.set(3,width)
            cap.set(4,height)
            
            #create a method that can seperate the foreground from the background
            fgbg = cv2.createBackgroundSubtractorMOG2()
            
            #setup outfile for writing video
            fourcc = cv2.VideoWriter_fourcc(*'DIVX')
            out = cv2.VideoWriter('/home/sm/Desktop/keyboard.avi',fourcc, 20.0, (1280,960))
            
            #define alphabet position
            position = 0
            #define hand position
            hand_position = 0,0
            hand_on_keyboard = False
            letter_selected = False
            #define font and text color
            font = cv2.FONT_HERSHEY_SIMPLEX
            color = (13,32,210)
            
            #create a list for the word
            word = ''
            
            #create a letter buffer
            letter_buffer = []
            
            #define frame_num
            frame_num = 0
            
            #function that determines distance between two points
            def distance(p0,p1):
                return math.sqrt((p1[1]-p0[1])**2+(p1[0]-p0[0])**2)
            
            #main loop
            while True:
            
                #read a frame from the webcam
                _, frame = cap.read()
                frame = cv2.flip(frame, 1)
                frame_num += 1
            
                #create a composite image that includes the webcam
                composite = frame.copy()
                
                #add the letters
                #make a list of letter positions
                letter_positions = []
                b=[]
                c = " "
                for letter in range(150):
                    x_position = position + letter*120
                    y_position = 150
                    xy = x_position, y_position
                    cv2.putText(composite,chr(40+letter),xy, font, 2,color,3)
                    letter_positions.append((chr(40+letter),xy))
                    #if there is a letter selected, make that letter blue
                    if letter_selected:
                        cv2.putText(composite, closest_letter, close_letter_position, font, 2, (255,0,0), 3)
                        
                #add a line to show where the keyboard starts
                cv2.line(composite, (composite.shape[1],200), (0,200), color, 2)
                
                #find the background
                #look only at the keyboard part of the frame
                look = frame[50:200, 0:frame.shape[1]]
                fgmask = fgbg.apply(look)
                
            
                #define apparent_motion as false
                apparent_motion = False
                letter_selected = False
                previous_position = hand_position
                #find the largest contour in the fgmask image
                a,c = cv2.findContours(fgmask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
                #draw a circle aroudn the contour
                for cnt in a:
                    (x,y),radius = cv2.minEnclosingCircle(cnt)
                    center = (int(x),int(y))
                    area = cv2.contourArea(cnt)
                    if area > 1000 and area < 2000:
                        radius = int(radius)
                        cv2.circle(composite,center,radius,(0,120,255), thickness=5)
                        cv2.line(composite, (center[0]-50,center[1]), (center[0]+50,center[1]), (0,0,0),3)
                        cv2.line(composite, (center[0],center[1]-50), (center[0],center[1]+50), (0,0,0),3)
                        letter_selected = True
                        #find the closest letter
                        closest_letter = 'a'
                        min_distance = 100000
                        for letter_tuple in letter_positions:
                            letter_position = letter_tuple[1]
                            if distance(letter_position, center) < min_distance:
                                closest_letter  = letter_tuple[0]
                                min_distance = distance(letter_position, center)
                                close_letter_position = letter_position
                                
                        letter_buffer.append(closest_letter)
                
                    #determine if there is apparent motion (swiping)
                    if area > 2000:
                        hand_position = center
                        if previous_position != (0,0):
                            apparent_motion = True
                            if previous_position[0] > hand_position[0]:
                                dirrection = 'Left'
                                position -=100
                            if previous_position[0] < hand_position[0]:
                                dirrection = 'Right'
                                position += 100
            
                        previous_position = hand_position
                #if a letter has been selected for 10 frames, write the letter and clear the buffer
                for letter in letter_buffer[20:]:
                    if letter == closest_letter:
                        word += letter
                        letter_buffer = []
                #write the word
                cv2.putText(composite, word, (50,50), font, 2, (0,0,0), 4)
                #show the various images and wait
                #cv2.imshow('fgmask',fgmask)
                #cv2.imshow('frame', frame)
                
                self.lineEdit.setText(word)
                qt_image = QtGui.QImage(composite.data, self.label_2.width(), self.label_2.height(),
                                        composite.strides[0], QtGui.QImage.Format_RGB888)
                
                convertToQtFormat = QtGui.QPixmap.fromImage(qt_image)
                pixmap = QPixmap(convertToQtFormat)
                QApplication.processEvents()
                self.label_2.setPixmap(pixmap)
                self.label_2.setScaledContents(True)
                self.label_2.show()
                
               
                #cv2.imshow('composite', composite)
                #out.write(composite)
                k = cv2.waitKey(30) & 0xff
                if k == 27:
                    break
            cap.release()
            cv2.destroyAllWindows()


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    
    sys.exit(app.exec_())
