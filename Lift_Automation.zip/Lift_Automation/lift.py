# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'lift.ui'
#
# Created by: PyQt5 UI code generator 5.11.2
#
# WARNING! All changes made in this file will be lost!

import tensorflow as tf
import tflearn
from tflearn.layers.conv import conv_2d,max_pool_2d
from tflearn.layers.core import input_data,dropout,fully_connected
from tflearn.layers.estimator import regression
import numpy as np
from PIL import Image
import cv2
import imutils
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt


# global variables
bg = None
#import pyautogui
#pyautogui.size()
#width, height= pyautogui.size()
class Ui_MainWindow1(object):

    def open_first(self):
        from VK import Ui_MainWindow as vkWindow
        self.camera.release
        cv2.destroyAllWindows()
        self.window = QtWidgets.QMainWindow()
        self.ui = vkWindow()
        self.ui.setupUi(self.window)
        #MainWindow.hide()
        #self.window.destroy()
        #QtWidgets.QMainWindow().close()
        self.window.show()
        #self.showMaximized()
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1366, 768)
        
        
        
       # MainWindow.setStyleSheet("background-image: url('pic.jpg');opacity: 0.4;background-size:cover;background-repeat:no-repeat;")
        MainWindow.setStyleSheet("background-color:#363b40;")
       
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.horizontalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget.setGeometry(QtCore.QRect(10, 30, 661, 481))
        self.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label = QtWidgets.QLabel(self.horizontalLayoutWidget)
        self.label.setObjectName("label")
        self.label.setStyleSheet('QLabel {font-size : 30px;color: #4CAF50;}')
        self.horizontalLayout.addWidget(self.label)
        self.verticalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(850, 20, 350, 481))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.label_3 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_3.setStyleSheet('QLabel {font-size : 30px;color:white;}')
        self.label_3.setFixedSize(200,200)
        self.label_3.setObjectName("label_3")
        self.verticalLayout_2.addWidget(self.label_3)
        self.label_4 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_4.setScaledContents(False)
        self.label_4.setObjectName("label_4")
        self.label_4.setStyleSheet('QLabel {font-size : 30px;color:white;}')
        self.verticalLayout_2.addWidget(self.label_4)
        self.lineEdit_2 = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.lineEdit_2.setStyleSheet("""QLineEdit
        {
     font-size:20pt;
     height:40px;
     width:150px;
     color:white
    }""")
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.verticalLayout_2.addWidget(self.lineEdit_2)
        self.label_5 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_5.setObjectName("label_5")
        self.label_5.setStyleSheet('QLabel {font-size : 30px;color:white;}')
        self.verticalLayout_2.addWidget(self.label_5)
        self.lineEdit = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit.setStyleSheet("""QLineEdit
        {
     font-size:20pt;
     height:40px;
     width:150px;
     color:white
    }""")
        self.verticalLayout_2.addWidget(self.lineEdit)
        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_2.setObjectName("label_2")
        self.label_2.setStyleSheet('QLabel {font-size : 30px;color:white;}')
        self.verticalLayout_2.addWidget(self.label_2)
        self.lineEdit_3 = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.lineEdit_3.setStyleSheet("""QLineEdit
        {
     font-size:20pt;
     height:40px;
     width:150px;
     color:white
    }""")
        self.verticalLayout_2.addWidget(self.lineEdit_3)
        self.horizontalLayoutWidget_2 = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget_2.setGeometry(QtCore.QRect(250, 520, 831, 80))
        self.horizontalLayoutWidget_2.setObjectName("horizontalLayoutWidget_2")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget_2)
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.pushButton_2 = QtWidgets.QPushButton(self.horizontalLayoutWidget_2)
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_2.setStyleSheet("""QPushButton { background-color: #4CAF50; border: none;
  color: white;
  padding: 15px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;}""")
        
        #self.pushButton_2.move(30,30)
        self.horizontalLayout_2.addWidget(self.pushButton_2)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem)
        self.pushButton = QtWidgets.QPushButton(self.horizontalLayoutWidget_2)
        self.pushButton.setObjectName("pushButton")
        #self.pushButton.resize(250, 100)
        self.pushButton.setStyleSheet("""QPushButton {background-color: #4CAF50; border: none;
  color: white;
  padding: 15px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;;}""")

        #self.pushButton.move(50,50)
        self.horizontalLayout_2.addWidget(self.pushButton)
        self.pushButton.clicked.connect(self.open_first)
        self.horizontalLayoutWidget_3 = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget_3.setGeometry(QtCore.QRect(500, 0, 831, 50))
        self.horizontalLayoutWidget_3.setObjectName("horizontalLayoutWidget_3")
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget_3)
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.label_6 = QtWidgets.QLabel(self.horizontalLayoutWidget_3)
        self.label_6.setObjectName("label_6")
        self.label_6.setStyleSheet('QLabel {font-size : 30px;color:white}')
        self.horizontalLayout_3.addWidget(self.label_6)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 851, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.camera = QtCore.QObject()
        self.camera = cv2.VideoCapture(0)
        
        self.pushButton_2.clicked.connect(self.gesture)
        self.pushButton.clicked.connect(MainWindow.close)
        

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        #self.label.setText(_translate("MainWindow", "GestureWindow"))
        self.label_3.setText(_translate("MainWindow", "Thresh"))
        self.label_4.setText(_translate("MainWindow", "Gesture"))
        self.label_5.setText(_translate("MainWindow", "Feature"))
        self.label_2.setText(_translate("MainWindow", "Confidence"))
        self.pushButton_2.setText(_translate("MainWindow", "AUTOMATED GESTURES"))
        self.pushButton.setText(_translate("MainWindow", "VIRTUAL KEYBOARD"))
        #self.pushButton.move(50,50)
        self.label_6.setText(_translate("MainWindow", "LIFT AUTOMATION DEMO"))

  



    def resizeImage(self,imageName):
        basewidth = 100
        img = Image.open(imageName)
        wpercent = (basewidth/float(img.size[0]))
        hsize = int((float(img.size[1])*float(wpercent)))
        img = img.resize((basewidth,hsize), Image.ANTIALIAS)
        img.save(imageName)

    def run_avg(self,image, aWeight):
        global bg
        # initialize the background
        if bg is None:
            bg = image.copy().astype("float")
            return

        # compute weighted average, accumulate it and update the background
        cv2.accumulateWeighted(image, bg, aWeight)

    def segment(self,image, threshold=25):
        global bg
        # find the absolute difference between background and current frame
        diff = cv2.absdiff(bg.astype("uint8"), image)

        # threshold the diff image so that we get the foreground
        thresholded = cv2.threshold(diff,
                                    threshold,
                                    255,
                                    cv2.THRESH_BINARY)[1]

        # get the contours in the thresholded image
        (cnts, _) = cv2.findContours(thresholded.copy(),
                                        cv2.RETR_EXTERNAL,
                                        cv2.CHAIN_APPROX_SIMPLE)

        # return None, if no contours detected
        if len(cnts) == 0:
            return
        else:
            # based on contour area, get the maximum contour which is the hand
            segmented = max(cnts, key=cv2.contourArea)
            return (thresholded, segmented)

    def gesture(self):
        # initialize weight for running average
        aWeight = 0.5

        # get the reference to the webcam
        #camera = cv2.VideoCapture(0)

        # region of interest (ROI) coordinates
        top, right, bottom, left = 10, 350, 225, 590

        # initialize num of frames
        num_frames = 0
        start_recording = False

        # keep looping, until interrupted
        while(True):
            # get the current frame
            (grabbed, frame) = self.camera.read()

            # resize the frame
            frame = imutils.resize(frame, width = 700)

            # flip the frame so that it is not the mirror view
            frame = cv2.flip(frame, 1)
            frame1 = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            # clone the frame
            clone = frame1.copy()
            clone1 = cv2.cvtColor(clone, cv2.COLOR_BGR2RGB)
            # get the height and width of the frame
            (height, width) = frame.shape[:2]

            # get the ROI
            roi = frame[top:bottom, right:left]

            # convert the roi to grayscale and blur it
            gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
            gray = cv2.GaussianBlur(gray, (7, 7), 0)

            # to get the background, keep looking till a threshold is reached
            # so that our running average model gets calibrated
            if num_frames < 30:
                self.run_avg(gray, aWeight)
            else:
                # segment the hand region
                hand = self.segment(gray)

                # check whether hand region is segmented
                if hand is not None:
                    # if yes, unpack the thresholded image and
                    # segmented region
                    (thresholded, segmented) = hand

                    

                    # draw the segmented region and display the frame
                    cv2.drawContours(clone, [segmented + (right, top)], -1, (0, 0, 255))
                    if start_recording:
                        cv2.imwrite('Temp.png', thresholded)
                        self.resizeImage('Temp.png')
                        predictedClass, confidence = self.getPredictedClass()
                        self.showStatistics(predictedClass, confidence)

                        if predictedClass == 0:
                            cv2.putText(clone,"Door is opening", (50,50), cv2.FONT_HERSHEY_SIMPLEX, 2, 2)
                            #with open("virtual_keyboard.py") as f:
                             #   code = compile(f.read(), "virtual_keyboard.py", 'exec')
                              #  exec(code)
                            #virtual.main()
                        elif predictedClass == 1:
                            cv2.putText(clone,"Light is on now", (50,50), cv2.FONT_HERSHEY_SIMPLEX, 2, 2)
                            self.lineEdit.setText("Light is on now")
                        elif predictedClass == 2:
                            cv2.putText(clone,"Door is closing", (50,50), cv2.FONT_HERSHEY_SIMPLEX, 2,2)
                            self.lineEdit.setText("Door is closing")
                        elif predictedClass == 3:
                            cv2.putText(clone,"Calling Emergency", (50,50), cv2.FONT_HERSHEY_SIMPLEX, 2, 2)
                            self.lineEdit.setText("Calling Emergency")
                        elif predictedClass == 4:
                            cv2.putText(clone,"Going upwords", (50,50), cv2.FONT_HERSHEY_SIMPLEX, 2, 2)
                            self.lineEdit.setText("Going upwords")
                        elif predictedClass == 5:
                            cv2.putText(clone,"Going Downwards", (50,50), cv2.FONT_HERSHEY_SIMPLEX, 2, 2)
                            self.lineEdit.setText("Going Downwards")
                        elif predictedClass == 6:
                            cv2.putText(clone,"Turning on the Fan", (50,50), cv2.FONT_HERSHEY_SIMPLEX, 2, 2)
                            self.lineEdit.setText("Turning on the Fan")
                        else:
                            cv2.putText(clone,"NOT RECOGNIZED", (50,50),cv2.FONT_HERSHEY_SIMPLEX, 2, 2)
                            self.lineEdit.setText("NOT RECOGNIZED")

                    width,height= thresholded.shape
                    thresholded=  thresholded.reshape(width,height,1)
                    qt_image = QtGui.QImage(thresholded.data, self.label_3.width(), self.label_3.height(),
                                                thresholded.strides[0], QtGui.QImage.Format_Grayscale8)
                    convertToQtFormat = QtGui.QPixmap.fromImage(qt_image)
                    pixmap = QPixmap(convertToQtFormat)
                    QApplication.processEvents()
                    self.label_3.setPixmap(pixmap)
                    self.label_3.setScaledContents(True)
                    self.label_3.show()
            # display the frame with segmented hand
            #cv2.imshow("Video Feed", clone)
                    #cv2.imshow("Thesholded", thresholded)

            # draw the segmented hand
            cv2.rectangle(clone, (left, top), (right, bottom), (0,255,0), 2)

            # increment the number of frames
            num_frames += 1
            width , height , _ = clone.shape
            qt_image = QtGui.QImage(clone.data, self.label.width(), self.label.height(),
                                        clone.strides[0], QtGui.QImage.Format_RGB888)
            convertToQtFormat = QtGui.QPixmap.fromImage(qt_image)
            pixmap = QPixmap(convertToQtFormat)
            QApplication.processEvents()
            self.label.setPixmap(pixmap)
            self.label.setScaledContents(True)
            self.label.show()

            # observe the keypress by the user
            #keypress = cv2.waitKey(1) & 0xFF

            # if the user pressed "q", then stop looping
            #if keypress == ord("q"):
                #break
            
            #if keypress == ord("s"):
            start_recording = True


    def getPredictedClass(self):
        # Predict
        image = cv2.imread('Temp.png')
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        prediction = model.predict([gray_image.reshape(89, 100, 1)])
        return np.argmax(prediction), (np.amax(prediction) / (prediction[0][0] + prediction[0][1] + prediction[0][2]))

    def showStatistics(self,predictedClass, confidence):

        textImage = np.zeros((300,512,3), np.uint8)
        className = ""

        if predictedClass == 0:
            className = "Swing"
        elif predictedClass == 1:
            className = "Palm"
        elif predictedClass == 2:
            className = "Fist"
        elif predictedClass == 3:
            className = "OK"
        elif predictedClass == 4:
            className = "ThumbsUp"
        elif predictedClass == 5:
            className = "ThumbDown"
        elif predictedClass == 6:
            className = "Victory"

        cv2.putText(textImage,"Predicted Class : " + className, 
        (30, 30), 
        cv2.FONT_HERSHEY_SIMPLEX, 
        1,
        (255, 255, 255),
        2)
        self.lineEdit_2.setText(className)

        cv2.putText(textImage,"Confidence : " + str(confidence * 100) + '%', 
        (30, 100), 
        cv2.FONT_HERSHEY_SIMPLEX, 
        1,
        (255, 255, 255),
        2)
        self.lineEdit_3.setText(str(round(confidence*100, 2)))
        #cv2.imshow("Statistics", textImage)

    # Model defined
tf.reset_default_graph()
convnet=input_data(shape=[None,89,100,1],name='input')
convnet=conv_2d(convnet,32,2,activation='relu')
convnet=max_pool_2d(convnet,2)
convnet=conv_2d(convnet,64,2,activation='relu')
convnet=max_pool_2d(convnet,2)

convnet=conv_2d(convnet,128,2,activation='relu')
convnet=max_pool_2d(convnet,2)

convnet=conv_2d(convnet,256,2,activation='relu')
convnet=max_pool_2d(convnet,2)

convnet=conv_2d(convnet,256,2,activation='relu')
convnet=max_pool_2d(convnet,2)

convnet=conv_2d(convnet,128,2,activation='relu')
convnet=max_pool_2d(convnet,2)

convnet=conv_2d(convnet,64,2,activation='relu')
convnet=max_pool_2d(convnet,2)

convnet=fully_connected(convnet,1000,activation='relu')
convnet=dropout(convnet,0.75)

convnet=fully_connected(convnet,7,activation='softmax')

convnet=regression(convnet,optimizer='adam',learning_rate=0.001,loss='categorical_crossentropy',name='regression')

model=tflearn.DNN(convnet,tensorboard_verbose=0)

# Load Saved Model
model.load("TrainedModel/GestureRecogModel.tfl")



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow1()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
