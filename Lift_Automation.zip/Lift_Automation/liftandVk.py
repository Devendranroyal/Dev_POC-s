# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'lift.ui'
#
# Created by: PyQt5 UI code generator 5.11.2
#
# WARNING! All changes made in this file will be lost!
import pkg_resources.py2_warn
import tensorflow as tf
import tflearn
from tflearn.layers.conv import conv_2d,max_pool_2d
from tflearn.layers.core import input_data,dropout,fully_connected
from tflearn.layers.estimator import regression
import numpy as np
from PIL import Image
import cv2
import imutils
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt


# global variables
bg = None

from PyQt5 import QtCore, QtGui, QtWidgets
import cv2
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication
import numpy as np
from PIL import Image
import os
import numpy as np
import pickle
import time
import pyautogui as gui
import sys
import numpy as np
#import Lift2
#from lift import Ui_MainWindow 

import cv2
import math
#import pyautogui
#pyautogui.size()
#width, height= pyautogui.size()
class Ui_MainWindow1(object):

    def open_first(self):
        #from VK import Ui_MainWindow as vkWindow
        self.camera.release
        cv2.destroyAllWindows()
        self.window = QtWidgets.QMainWindow()
        #self.ui = vkWindow()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self.window)
        #MainWindow.hide()
        #self.window.destroy()
        #QtWidgets.QMainWindow().close()
        self.window.show()
        #self.showMaximized()
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1366, 768)
        
        
        
       # MainWindow.setStyleSheet("background-image: url('pic.jpg');opacity: 0.4;background-size:cover;background-repeat:no-repeat;")
        MainWindow.setStyleSheet("background-color:#363b40;")
       
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.horizontalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget.setGeometry(QtCore.QRect(10, 30, 661, 481))
        self.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label = QtWidgets.QLabel(self.horizontalLayoutWidget)
        self.label.setObjectName("label")
        self.label.setStyleSheet('QLabel {font-size : 30px;color: #4CAF50;}')
        self.horizontalLayout.addWidget(self.label)
        self.verticalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(850, 20, 350, 481))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.label_3 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_3.setStyleSheet('QLabel {font-size : 30px;color:white;}')
        self.label_3.setFixedSize(200,200)
        self.label_3.setObjectName("label_3")
        self.verticalLayout_2.addWidget(self.label_3)
        self.label_4 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_4.setScaledContents(False)
        self.label_4.setObjectName("label_4")
        self.label_4.setStyleSheet('QLabel {font-size : 30px;color:white;}')
        self.verticalLayout_2.addWidget(self.label_4)
        self.lineEdit_2 = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.lineEdit_2.setStyleSheet("""QLineEdit
        {
     font-size:20pt;
     height:40px;
     width:150px;
     color:white
    }""")
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.verticalLayout_2.addWidget(self.lineEdit_2)
        self.label_5 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_5.setObjectName("label_5")
        self.label_5.setStyleSheet('QLabel {font-size : 30px;color:white;}')
        self.verticalLayout_2.addWidget(self.label_5)
        self.lineEdit = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit.setStyleSheet("""QLineEdit
        {
     font-size:20pt;
     height:40px;
     width:150px;
     color:white
    }""")
        self.verticalLayout_2.addWidget(self.lineEdit)
        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_2.setObjectName("label_2")
        self.label_2.setStyleSheet('QLabel {font-size : 30px;color:white;}')
        self.verticalLayout_2.addWidget(self.label_2)
        self.lineEdit_3 = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.lineEdit_3.setStyleSheet("""QLineEdit
        {
     font-size:20pt;
     height:40px;
     width:150px;
     color:white
    }""")
        self.verticalLayout_2.addWidget(self.lineEdit_3)
        self.horizontalLayoutWidget_2 = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget_2.setGeometry(QtCore.QRect(250, 520, 831, 80))
        self.horizontalLayoutWidget_2.setObjectName("horizontalLayoutWidget_2")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget_2)
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.pushButton_2 = QtWidgets.QPushButton(self.horizontalLayoutWidget_2)
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_2.setStyleSheet("""QPushButton { background-color: #4CAF50; border: none;
  color: white;
  padding: 15px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;}""")
        
        #self.pushButton_2.move(30,30)
        self.horizontalLayout_2.addWidget(self.pushButton_2)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem)
        self.pushButton = QtWidgets.QPushButton(self.horizontalLayoutWidget_2)
        self.pushButton.setObjectName("pushButton")
        #self.pushButton.resize(250, 100)
        self.pushButton.setStyleSheet("""QPushButton {background-color: #4CAF50; border: none;
  color: white;
  padding: 15px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;;}""")

        #self.pushButton.move(50,50)
        self.horizontalLayout_2.addWidget(self.pushButton)
        self.pushButton.clicked.connect(self.open_first)
        self.horizontalLayoutWidget_3 = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget_3.setGeometry(QtCore.QRect(500, 0, 831, 50))
        self.horizontalLayoutWidget_3.setObjectName("horizontalLayoutWidget_3")
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget_3)
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.label_6 = QtWidgets.QLabel(self.horizontalLayoutWidget_3)
        self.label_6.setObjectName("label_6")
        self.label_6.setStyleSheet('QLabel {font-size : 30px;color:white}')
        self.horizontalLayout_3.addWidget(self.label_6)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 851, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.camera = QtCore.QObject()
        self.camera = cv2.VideoCapture(0)
        
        self.pushButton_2.clicked.connect(self.gesture)
        self.pushButton.clicked.connect(MainWindow.close)
        #self.pushButton.clicked.connect(self.)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        #self.label.setText(_translate("MainWindow", "GestureWindow"))
        self.label_3.setText(_translate("MainWindow", "Thresh"))
        self.label_4.setText(_translate("MainWindow", "Gesture"))
        self.label_5.setText(_translate("MainWindow", "Feature"))
        self.label_2.setText(_translate("MainWindow", "Confidence"))
        self.pushButton_2.setText(_translate("MainWindow", "AUTOMATED GESTURES"))
        self.pushButton.setText(_translate("MainWindow", "VIRTUAL KEYBOARD"))
        #self.pushButton.move(50,50)
        self.label_6.setText(_translate("MainWindow", "LIFT AUTOMATION DEMO"))

    '''def Video(self):
        while True:
            ret, frame = self.cap.read()
            cv2image = cv2.cvtcolor(frame, cv2.COLOR_BGR2RGB)
            width , height , _ = cv2image.shape
            qt_image = QtGui.QImage(cv2image.data, self.label.width(), self.label.height(),
                                        cv2image.strides[0], QtGui.QImage.Format_RGB888)
            convertToQtFormat = QtGui.QPixmap.fromImage(qt_image)
            pixmap = QPixmap(convertToQtFormat)
            QApplication.processEvents()
            self.label.setPixmap(pixmap)
            self.label.setScaledContents(True)
            self.label.show()'''




    def resizeImage(self,imageName):
        basewidth = 100
        img = Image.open(imageName)
        wpercent = (basewidth/float(img.size[0]))
        hsize = int((float(img.size[1])*float(wpercent)))
        img = img.resize((basewidth,hsize), Image.ANTIALIAS)
        img.save(imageName)

    def run_avg(self,image, aWeight):
        global bg
        # initialize the background
        if bg is None:
            bg = image.copy().astype("float")
            return

        # compute weighted average, accumulate it and update the background
        cv2.accumulateWeighted(image, bg, aWeight)

    def segment(self,image, threshold=25):
        global bg
        # find the absolute difference between background and current frame
        diff = cv2.absdiff(bg.astype("uint8"), image)

        # threshold the diff image so that we get the foreground
        thresholded = cv2.threshold(diff,
                                    threshold,
                                    255,
                                    cv2.THRESH_BINARY)[1]

        # get the contours in the thresholded image
        (cnts, _) = cv2.findContours(thresholded.copy(),
                                        cv2.RETR_EXTERNAL,
                                        cv2.CHAIN_APPROX_SIMPLE)

        # return None, if no contours detected
        if len(cnts) == 0:
            return
        else:
            # based on contour area, get the maximum contour which is the hand
            segmented = max(cnts, key=cv2.contourArea)
            return (thresholded, segmented)

    def gesture(self):
        # initialize weight for running average
        aWeight = 0.5

        # get the reference to the webcam
        #camera = cv2.VideoCapture(0)

        # region of interest (ROI) coordinates
        top, right, bottom, left = 10, 350, 225, 590

        # initialize num of frames
        num_frames = 0
        start_recording = False

        # keep looping, until interrupted
        while(True):
            # get the current frame
            (grabbed, frame) = self.camera.read()

            # resize the frame
            frame = imutils.resize(frame, width = 700)

            # flip the frame so that it is not the mirror view
            frame = cv2.flip(frame, 1)
            frame1 = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            # clone the frame
            clone = frame1.copy()
            clone1 = cv2.cvtColor(clone, cv2.COLOR_BGR2RGB)
            # get the height and width of the frame
            (height, width) = frame.shape[:2]

            # get the ROI
            roi = frame[top:bottom, right:left]

            # convert the roi to grayscale and blur it
            gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
            gray = cv2.GaussianBlur(gray, (7, 7), 0)

            # to get the background, keep looking till a threshold is reached
            # so that our running average model gets calibrated
            if num_frames < 30:
                self.run_avg(gray, aWeight)
            else:
                # segment the hand region
                hand = self.segment(gray)

                # check whether hand region is segmented
                if hand is not None:
                    # if yes, unpack the thresholded image and
                    # segmented region
                    (thresholded, segmented) = hand

                    

                    # draw the segmented region and display the frame
                    cv2.drawContours(clone, [segmented + (right, top)], -1, (0, 0, 255))
                    if start_recording:
                        cv2.imwrite('Temp.png', thresholded)
                        self.resizeImage('Temp.png')
                        predictedClass, confidence = self.getPredictedClass()
                        self.showStatistics(predictedClass, confidence)

                        if predictedClass == 0:
                            cv2.putText(clone,"Door is opening", (50,50), cv2.FONT_HERSHEY_SIMPLEX, 2, 2)
                            #with open("virtual_keyboard.py") as f:
                             #   code = compile(f.read(), "virtual_keyboard.py", 'exec')
                              #  exec(code)
                            #virtual.main()
                        elif predictedClass == 1:
                            cv2.putText(clone,"Light is on now", (50,50), cv2.FONT_HERSHEY_SIMPLEX, 2, 2)
                            self.lineEdit.setText("Light is on now")
                        elif predictedClass == 2:
                            cv2.putText(clone,"Door is closing", (50,50), cv2.FONT_HERSHEY_SIMPLEX, 2,2)
                            self.lineEdit.setText("Door is closing")
                        elif predictedClass == 3:
                            cv2.putText(clone,"Calling Emergency", (50,50), cv2.FONT_HERSHEY_SIMPLEX, 2, 2)
                            self.lineEdit.setText("Calling Emergency")
                        elif predictedClass == 4:
                            cv2.putText(clone,"Going upwords", (50,50), cv2.FONT_HERSHEY_SIMPLEX, 2, 2)
                            self.lineEdit.setText("Going upwords")
                        elif predictedClass == 5:
                            cv2.putText(clone,"Going Downwards", (50,50), cv2.FONT_HERSHEY_SIMPLEX, 2, 2)
                            self.lineEdit.setText("Going Downwards")
                        elif predictedClass == 6:
                            cv2.putText(clone,"Turning on the Fan", (50,50), cv2.FONT_HERSHEY_SIMPLEX, 2, 2)
                            self.lineEdit.setText("Turning on the Fan")
                        else:
                            cv2.putText(clone,"NOT RECOGNIZED", (50,50),cv2.FONT_HERSHEY_SIMPLEX, 2, 2)
                            self.lineEdit.setText("NOT RECOGNIZED")

                    width,height= thresholded.shape
                    thresholded=  thresholded.reshape(width,height,1)
                    qt_image = QtGui.QImage(thresholded.data, self.label_3.width(), self.label_3.height(),
                                                thresholded.strides[0], QtGui.QImage.Format_Grayscale8)
                    convertToQtFormat = QtGui.QPixmap.fromImage(qt_image)
                    pixmap = QPixmap(convertToQtFormat)
                    QApplication.processEvents()
                    self.label_3.setPixmap(pixmap)
                    self.label_3.setScaledContents(True)
                    self.label_3.show()
            # display the frame with segmented hand
            #cv2.imshow("Video Feed", clone)
                    #cv2.imshow("Thesholded", thresholded)

            # draw the segmented hand
            cv2.rectangle(clone, (left, top), (right, bottom), (0,255,0), 2)

            # increment the number of frames
            num_frames += 1
            width , height , _ = clone.shape
            qt_image = QtGui.QImage(clone.data, self.label.width(), self.label.height(),
                                        clone.strides[0], QtGui.QImage.Format_RGB888)
            convertToQtFormat = QtGui.QPixmap.fromImage(qt_image)
            pixmap = QPixmap(convertToQtFormat)
            QApplication.processEvents()
            self.label.setPixmap(pixmap)
            self.label.setScaledContents(True)
            self.label.show()

            # observe the keypress by the user
            #keypress = cv2.waitKey(1) & 0xFF

            # if the user pressed "q", then stop looping
            #if keypress == ord("q"):
                #break
            
            #if keypress == ord("s"):
            start_recording = True


    def getPredictedClass(self):
        # Predict
        image = cv2.imread('Temp.png')
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        prediction = model.predict([gray_image.reshape(89, 100, 1)])
        return np.argmax(prediction), (np.amax(prediction) / (prediction[0][0] + prediction[0][1] + prediction[0][2]))

    def showStatistics(self,predictedClass, confidence):

        textImage = np.zeros((300,512,3), np.uint8)
        className = ""

        if predictedClass == 0:
            className = "Swing"
        elif predictedClass == 1:
            className = "Palm"
        elif predictedClass == 2:
            className = "Fist"
        elif predictedClass == 3:
            className = "OK"
        elif predictedClass == 4:
            className = "ThumbsUp"
        elif predictedClass == 5:
            className = "ThumbDown"
        elif predictedClass == 6:
            className = "Victory"

        cv2.putText(textImage,"Predicted Class : " + className, 
        (30, 30), 
        cv2.FONT_HERSHEY_SIMPLEX, 
        1,
        (255, 255, 255),
        2)
        self.lineEdit_2.setText(className)

        cv2.putText(textImage,"Confidence : " + str(confidence * 100) + '%', 
        (30, 100), 
        cv2.FONT_HERSHEY_SIMPLEX, 
        1,
        (255, 255, 255),
        2)
        self.lineEdit_3.setText(str(round(confidence*100, 2)))
        #cv2.imshow("Statistics", textImage)

    # Model defined
tf.reset_default_graph()
convnet=input_data(shape=[None,89,100,1],name='input')
convnet=conv_2d(convnet,32,2,activation='relu')
convnet=max_pool_2d(convnet,2)
convnet=conv_2d(convnet,64,2,activation='relu')
convnet=max_pool_2d(convnet,2)

convnet=conv_2d(convnet,128,2,activation='relu')
convnet=max_pool_2d(convnet,2)

convnet=conv_2d(convnet,256,2,activation='relu')
convnet=max_pool_2d(convnet,2)

convnet=conv_2d(convnet,256,2,activation='relu')
convnet=max_pool_2d(convnet,2)

convnet=conv_2d(convnet,128,2,activation='relu')
convnet=max_pool_2d(convnet,2)

convnet=conv_2d(convnet,64,2,activation='relu')
convnet=max_pool_2d(convnet,2)

convnet=fully_connected(convnet,1000,activation='relu')
convnet=dropout(convnet,0.75)

convnet=fully_connected(convnet,7,activation='softmax')

convnet=regression(convnet,optimizer='adam',learning_rate=0.001,loss='categorical_crossentropy',name='regression')

model=tflearn.DNN(convnet,tensorboard_verbose=0)

# Load Saved Model
model.load("TrainedModel/GestureRecogModel.tfl")

class Ui_MainWindow(object):
    
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1366, 768)
        
        MainWindow.setStyleSheet("background-color:#363b40;")
        
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(300, 70, 781, 541))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_2.setObjectName("label_2")
        self.verticalLayout.addWidget(self.label_2)
        self.label_2.setFixedSize(1250,350)
        self.label_2.setStyleSheet('QLabel {font-size : 30px;color:white;}')
        self.pushButton = QtWidgets.QPushButton(self.verticalLayoutWidget)
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout.addWidget(self.pushButton)
        self.pushButton.setText("Start")
        self.pushButton.setStyleSheet("""QPushButton { background-color: #4CAF50; border: none;
      color: white;
      padding: 10px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 20px;}""")

        self.pushButton2 = QtWidgets.QPushButton(self.verticalLayoutWidget)
        self.pushButton2.setObjectName("pushButton2")
        self.verticalLayout.addWidget(self.pushButton2)
        self.pushButton2.setText("Stop And Exit")
        self.pushButton2.setStyleSheet("""QPushButton { background-color: #4CAF50; border: none;
      color: white;
      padding: 10px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 20px;}""")
        
        self.pushButton3 = QtWidgets.QPushButton(self.verticalLayoutWidget)
        self.pushButton3.setObjectName("pushButton3")
        self.verticalLayout.addWidget(self.pushButton3)
        self.pushButton3.setText("Back")
        self.pushButton3.setStyleSheet("""QPushButton { background-color: #4CAF50; border: none;
      color: white;
      padding: 10px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 20px;}""")
        
        

        self.label = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label.setObjectName("label")
        self.label.setStyleSheet('QLabel {font-size : 30px;color:white;}')

        self.verticalLayout.addWidget(self.label)
        self.lineEdit = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit.setStyleSheet("""QLineEdit
        {
     font-size:20pt;
     height:40px;
     width:150px;
     color:white
    }""")
    
        
        
        
        self.verticalLayout.addWidget(self.lineEdit)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.cam = QtCore.QObject()
        self.cam = cv2.VideoCapture(0)

        with open("range.pickle", "rb") as f:       # range.pickle is generated by range-detector.py
            self.t = pickle.load(f)
        #self.cam = cv2.VideoCapture(0)
        '''if self.cam.read()[0]==False:
                                    self.cam=cv2.VideoCapture(0)'''
        self.hsv_lower = np.array([self.t[0], self.t[1], self.t[2]])    
        self.hsv_upper = np.array([self.t[3], self.t[4], self.t[5]])
        self.width = self.cam.get(cv2.CAP_PROP_FRAME_WIDTH)   # width of video captured by the webcam
        self.height = self.cam.get(cv2.CAP_PROP_FRAME_HEIGHT)
        
        self.pushButton4 = QtWidgets.QPushButton(self.verticalLayoutWidget)
        self.pushButton4.setObjectName("pushButton4")
        self.verticalLayout.addWidget(self.pushButton4)
        self.pushButton4.setText("Reset")
        self.pushButton4.setStyleSheet("""QPushButton { background-color: #4CAF50; border: none;
      color: white;
      padding: 10px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 20px;}""")

        self.pushButton.clicked.connect(self.virtual )
        self.pushButton2.clicked.connect(self.destroy)
        self.pushButton3.clicked.connect(self.Back)
        self.pushButton3.clicked.connect(MainWindow.close)
        self.pushButton4.clicked.connect(self.virtual )
        
    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_2.setText(_translate("MainWindow", "VIRTUAL KEYBOARD"))
        self.label.setText(_translate("MainWindow", "FLOOR NUMBER"))

    def destroy(self):
        self.cam.release()
        cv2.destroyAllWindows()
        sys.exit(0)

    def Back(self):
        from lift import Ui_MainWindow1 as liftWindow
        self.window = QtWidgets.QMainWindow()
        self.ui = liftWindow()
        self.ui.setupUi(self.window)
        self.window.show()
        #MainWindow.hide()
    
   #self.window.hide()
    def get_keys(self):
        max_keys_in_a_row = 11                     # max number of keys in any row is 10 i.e the first row which contains 1234567890'backspace'
        key_width = int(self.width/max_keys_in_a_row)    # width of one key. width is divided by 10 as the max number of keys in a single row is 11.
    
        row0_key_width = key_width * 11         # width of zeroth or numeric row of keys
        row1_key_width = key_width * 10         # width of first row
        row2_key_width = key_width * 9          # width of second row
        row3_key_width = key_width * 7          # width of third row
        row4_key_width = key_width * 5          # width of space
        row_keys = []                           # stores the keys along with its 2 corner coordinates and the center coordinate

        # for the zeroth row
        x1, y1 = 0, int((self.height - key_width * 5) / 2)   # 5 is due to the fact that we will have 5 rows. y1 is set such that the whole keyboard has equal margin on both top and bottom
        x2, y2 = key_width + x1, key_width + y1
        c1, c2 = x1, y1                 # copying x1, x2, y1 and y2
        keys = "1 2 3 4 5 6 7 8 9 0 <-"
        keys = keys.split(" ")
        for key in keys:
            if key == "<-":
                row_keys.append([key, (x1, y1), (x2, y2), (int((x2+x1)/2) - 25, int((y2+y1)/2) + 10)])
            else:
                row_keys.append([key, (x1, y1), (x2, y2), (int((x2+x1)/2) - 5, int((y2+y1)/2) + 10)])
            x1 += key_width
            x2 += key_width
        x1, y1 = c1, c2                 # copying back from c1, c2, c3 and c4

        # for the first row
        x1, y1 = int((row0_key_width - row1_key_width) / 2) + x1, y1 + key_width    
        x2, y2 = key_width + x1, key_width + y1
        c1, c2 = x1, y1                 # copying x1, x2, y1 and y2
        keys = "qwertyuiop"
        for key in keys:
            row_keys.append([key, (x1, y1), (x2, y2), (int((x2+x1)/2) - 5, int((y2+y1)/2) + 10)])
            x1 += key_width
            x2 += key_width
        x1, y1 = c1, c2                 # copying back from c1, c2, c3 and c4

        # for second row
        x1, y1 = int((row1_key_width - row2_key_width) / 2) + x1, y1 + key_width   # x1 is set such that it leaves equal margin on both left and right side
        x2, y2 = key_width + x1, key_width + y1
        c1, c2 = x1, y1
        keys = "asdfghjkl"
        for key in keys:
            row_keys.append([key, (x1, y1), (x2, y2), (int((x2+x1)/2) - 5, int((y2+y1)/2) + 10)])
            x1 += key_width
            x2 += key_width
        x1, y1 = c1, c2

        # for third row
        x1, y1 = int((row2_key_width - row3_key_width) / 2) + x1, y1 + key_width
        x2, y2 = key_width + x1, key_width + y1 
        c1, c2 = x1, y1 
        keys = "zxcvbnm"
        for key in keys:
            row_keys.append([key, (x1, y1), (x2, y2), (int((x2+x1)/2) - 5, int((y2+y1)/2) + 10)])
            x1 += key_width
            x2 += key_width
        x1, y1 = c1, c2

        # for the space bar
        x1, y1 = int((row3_key_width - row4_key_width) / 2) + x1, y1 + key_width
        x2, y2 = 5 * key_width + x1, key_width + y1 
        c1, c2 = x1, y1 
        keys = " "
        for key in keys:
            row_keys.append([key, (x1, y1), (x2, y2), (int((x2+x1)/2) - 5, int((y2+y1)/2) + 10)])
            x1 += key_width
            x2 += key_width
        x1, y1 = c1, c2

        return row_keys


    def do_keypress(self,img, center, row_keys_points):
        # this fuction presses a key and marks the pressed key with blue color
        for row in row_keys_points:
            arr1 = list(np.int0(np.array(center) >= np.array(row[1])))          # center of the contour has greater value than the top left corner point of a key 
            arr2 = list(np.int0(np.array(center) <= np.array(row[2])))          # center of the contour has less value than the bottom right corner point of a key 
            if arr1 == [1, 1] and arr2 == [1, 1]:
                if row[0] == '<-':
                    gui.press('backspace')
                else:
                    gui.press(row[0])
                cv2.fillConvexPoly(img, np.array([np.array(row[1]), \
                                                    np.array([row[1][0], row[2][1]]), \
                                                    np.array(row[2]), \
                                                    np.array([row[2][0], row[1][1]])]), \
                                                    (255, 0, 0))
        return img


    def keyboard(self):
        row_keys_points = self.get_keys()
        new_area, old_area = 0, 0
        c, c2 = 0, 0                        # c stores the number of iterations for calculating the difference b/w present area and previous area
                                    # c2 stores the number of iterations for calculating the difference b/w present center and previous center
        flag_keypress = False                  # if a key is pressed then this flag is True
        while True:
            ret, img = self.cam.read()
            #cv2.imshow("IMAGE",img)
            img = cv2.flip(img, 1)
            imgHSV = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
            mask = cv2.inRange(imgHSV, self.hsv_lower, self.hsv_upper)
            blur = cv2.medianBlur(mask, 15)
            blur = cv2.GaussianBlur(blur , (5,5), 0)
            _, thresh = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
            contours, hierarchy = cv2.findContours(thresh.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
            #print(contours)

            if len(contours) > 0:
                cnt = max(contours, key = cv2.contourArea)
                if cv2.contourArea(cnt) > 350:
                    # draw a rectangle and a center 
                    rect = cv2.minAreaRect(cnt)
                    center = list(rect[0])
                    box = cv2.boxPoints(rect)
                    box = np.int0(box)
                    cv2.circle(img, tuple(np.int0(center)), 2, (0, 255, 0), 2)
                    cv2.drawContours(img,[box],0,(0,0,255),2)
                    
                    # calculation of difference of area and center
                    new_area = cv2.contourArea(cnt)
                    new_center = np.int0(center)
                    if c == 0:
                        old_area = new_area
                    c += 1
                    diff_area = 0
                    if c > 3:               # after every 3rd iteration difference of area is calculated
                        diff_area = new_area - old_area
                        c = 0
                    if c2 == 0:
                        old_center = new_center
                    c2 += 1
                    diff_center = np.array([0, 0])
                    if c2 > 5:              # after every 5th iteration difference of center is claculated
                        diff_center = new_center - old_center
                        c2 = 0
                    
                    # setting some thresholds
                    center_threshold = 10
                    area_threshold = 200
                    if abs(diff_center[0]) < center_threshold or abs(diff_center[1]) < center_threshold:
                        print(diff_area)
                        if diff_area > area_threshold and flag_keypress == False:
                            img = self.do_keypress(img, new_center, row_keys_points)
                            flag_keypress = True
                        elif diff_area < -(area_threshold) and flag_keypress == True:
                            flag_keypress = False
                else:
                    flag_keypress = False
            else:
                flag_keypress = False

            # displaying the keyboard
            for key in row_keys_points:
                cv2.putText(img, key[0], key[3], cv2.FONT_HERSHEY_DUPLEX, 1, (0, 255, 0))
                cv2.rectangle(img, key[1], key[2], (0, 255, 0), thickness = 2)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            width , height , _ = img.shape
            qt_image = QtGui.QImage(img.data, self.label_2.width(), self.label_2.height(),
                                        img.strides[0], QtGui.QImage.Format_RGB888)
            convertToQtFormat = QtGui.QPixmap.fromImage(qt_image)
            pixmap = QPixmap(convertToQtFormat)
            QApplication.processEvents()
            self.label_2.setPixmap(pixmap)
            self.label_2.setScaledContents(True)
            self.label_2.show()
            #cv2.imshow("img", img)
     
            
    def virtual(self):      
            cap = cv2.VideoCapture(0)
            width, height = 1920,1080
            cap.set(3,width)
            cap.set(4,height)
            
            #create a method that can seperate the foreground from the background
            fgbg = cv2.createBackgroundSubtractorMOG2()
            
            #setup outfile for writing video
            fourcc = cv2.VideoWriter_fourcc(*'DIVX')
            out = cv2.VideoWriter('/home/sm/Desktop/keyboard.avi',fourcc, 20.0, (1280,960))
            
            #define alphabet position
            position = 0
            #define hand position
            hand_position = 0,0
            hand_on_keyboard = False
            letter_selected = False
            #define font and text color
            font = cv2.FONT_HERSHEY_SIMPLEX
            color = (13,32,210)
            
            #create a list for the word
            word = ''
            
            #create a letter buffer
            letter_buffer = []
            
            #define frame_num
            frame_num = 0
            
            #function that determines distance between two points
            def distance(p0,p1):
                return math.sqrt((p1[1]-p0[1])**2+(p1[0]-p0[0])**2)
            
            #main loop
            while True:
            
                #read a frame from the webcam
                _, frame = cap.read()
                frame = cv2.flip(frame, 1)
                frame_num += 1
            
                #create a composite image that includes the webcam
                composite = frame.copy()
                
                #add the letters
                #make a list of letter positions
                letter_positions = []
                b=[]
                c = " "
                for letter in range(150):
                    x_position = position + letter*120
                    y_position = 150
                    xy = x_position, y_position
                    cv2.putText(composite,chr(40+letter),xy, font, 2,color,3)
                    letter_positions.append((chr(40+letter),xy))
                    #if there is a letter selected, make that letter blue
                    if letter_selected:
                        cv2.putText(composite, closest_letter, close_letter_position, font, 2, (255,0,0), 3)
                        
                #add a line to show where the keyboard starts
                cv2.line(composite, (composite.shape[1],200), (0,200), color, 2)
                
                #find the background
                #look only at the keyboard part of the frame
                look = frame[50:200, 0:frame.shape[1]]
                fgmask = fgbg.apply(look)
                
            
                #define apparent_motion as false
                apparent_motion = False
                letter_selected = False
                previous_position = hand_position
                #find the largest contour in the fgmask image
                a,c = cv2.findContours(fgmask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
                #draw a circle aroudn the contour
                for cnt in a:
                    (x,y),radius = cv2.minEnclosingCircle(cnt)
                    center = (int(x),int(y))
                    area = cv2.contourArea(cnt)
                    if area > 1000 and area < 2000:
                        radius = int(radius)
                        cv2.circle(composite,center,radius,(0,120,255), thickness=5)
                        cv2.line(composite, (center[0]-50,center[1]), (center[0]+50,center[1]), (0,0,0),3)
                        cv2.line(composite, (center[0],center[1]-50), (center[0],center[1]+50), (0,0,0),3)
                        letter_selected = True
                        #find the closest letter
                        closest_letter = 'a'
                        min_distance = 100000
                        for letter_tuple in letter_positions:
                            letter_position = letter_tuple[1]
                            if distance(letter_position, center) < min_distance:
                                closest_letter  = letter_tuple[0]
                                min_distance = distance(letter_position, center)
                                close_letter_position = letter_position
                                
                        letter_buffer.append(closest_letter)
                
                    #determine if there is apparent motion (swiping)
                    if area > 2000:
                        hand_position = center
                        if previous_position != (0,0):
                            apparent_motion = True
                            if previous_position[0] > hand_position[0]:
                                dirrection = 'Left'
                                position -=100
                            if previous_position[0] < hand_position[0]:
                                dirrection = 'Right'
                                position += 100
            
                        previous_position = hand_position
                #if a letter has been selected for 10 frames, write the letter and clear the buffer
                for letter in letter_buffer[20:]:
                    if letter == closest_letter:
                        word += letter
                        letter_buffer = []
                #write the word
                cv2.putText(composite, word, (50,50), font, 2, (0,0,0), 4)
                #show the various images and wait
                #cv2.imshow('fgmask',fgmask)
                #cv2.imshow('frame', frame)
                
                self.lineEdit.setText(word)
                qt_image = QtGui.QImage(composite.data, self.label_2.width(), self.label_2.height(),
                                        composite.strides[0], QtGui.QImage.Format_RGB888)
                
                convertToQtFormat = QtGui.QPixmap.fromImage(qt_image)
                pixmap = QPixmap(convertToQtFormat)
                QApplication.processEvents()
                self.label_2.setPixmap(pixmap)
                self.label_2.setScaledContents(True)
                self.label_2.show()
                
               
                #cv2.imshow('composite', composite)
                #out.write(composite)
                k = cv2.waitKey(30) & 0xff
                if k == 27:
                    break
            cap.release()
            cv2.destroyAllWindows()


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow1()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
