import time as tm,tkinter as tk,pandas as pd,matplotlib.pyplot as plt
import pandas as pd
import numpy as np 
import os
from mlxtend.frequent_patterns import apriori
from mlxtend.preprocessing import TransactionEncoder    #object for apriori
from PIL import Image as IMG, ImageDraw, ImageTk     #for text to image
from tkinter import Frame, Button, Label



filename='database.csv'
columns=['Date','Time','Name','Mobile Number','Product','Total Amount']
root1=tk.Tk()



#root1.minsize(width=1020,height=1980)
root=tk.Frame(root1)


#root1.place(width=1000,height=1980)
#root1.attributes('-fullscreen', True)
#root.pack()
root1.title('Retail billing and Recommend')
root1.geometry('1500x1980')
root.place(width=1500,height=1980)

background_image = ImageTk.PhotoImage(IMG.open("C:\\Users\\HP\\Downloads\\mark-kirkpatrick-mk-landscape-01 (1).jpg"))
background_label45 = Label(root,image=background_image)
background_label45.image = background_image
background_label45.place(x=0, y=0)


'''
background_image=tk.PhotoImage(IMG.open("C:\\Users\\HP\\Downloads\\mark-kirkpatrick-mk-landscape-01 (1).jpg"))
background_label = tk.Label(parent, image=background_image)
background_label.place(x=0, y=0, relwidth=1, relheight=1)
'''


row=300
num=1   #serial number
Product,Price='',[]
ItemsPurchased=[]
totalAmount=[]
global dataDict
def time():     #function to display date and time
    global TM,DT,q
    DT=""
    TM=""
    time1=q=tm.ctime(tm.time()).split(sep=' ')[-2]
    dateV=list(tm.localtime()[:3])
    q=q[:len(q)-3]
    for i in dateV:
        DT+=str(i)
        DT+='/'
    DT=DT[:len(DT)-1]
    date=tk.Label(root,bg='misty rose',text='Date:  '+DT+'\tTime:  '+str(q),bd=3,font=(30))
    #date.grid(column=250,row=4)
    date.place(x=1020,y=50)
	

from tkinter import *
import re
class AutocompleteEntry(Entry):
    def __init__(self, lista, *args, **kwargs):
        
        Entry.__init__(self, *args, **kwargs)
        self.lista = lista        
        self.var = self["textvariable"]
        if self.var == '':
            self.var = self["textvariable"] = StringVar()

        self.var.trace('w', self.changed)
        self.bind("<Right>", self.selection)
        self.bind("<Up>", self.up)
        self.bind("<Down>", self.down)
        
        self.lb_up = False

    def changed(self, name, index, mode):  

        if self.var.get() == '':
            self.lb.destroy()
            self.lb_up = False
        else:
            words = self.comparison()
            if words:            
                if not self.lb_up:
                    self.lb = Listbox()
                    self.lb.bind("<Double-Button-1>", self.selection)
                    self.lb.bind("<Right>", self.selection)
                    self.lb.place(x=self.winfo_x(), y=self.winfo_y()+self.winfo_height())
                    self.lb_up = True
                    
                self.lb.delete(0, END)
                for w in words:
                    self.lb.insert(END,w)
                    
            else:
                if self.lb_up:
                    self.lb.destroy()
                    self.lb_up = False
        
    def selection(self, event):

        if self.lb_up:
            self.var.set(self.lb.get(ACTIVE))
            self.lb.destroy()
            self.lb_up = False
            self.icursor(END)

    def up(self, event):

        if self.lb_up:
            if self.lb.curselection() == ():
                index = '0'
            else:
                index = self.lb.curselection()[0]
            if index != '0':                
                self.lb.selection_clear(first=index)
                index = str(int(index)-1)                
                self.lb.selection_set(first=index)
                self.lb.activate(index) 

    def down(self, event):

        if self.lb_up:
            if self.lb.curselection() == ():
                index = '0'
            else:
                index = self.lb.curselection()[0]
            if index != END:                        
                self.lb.selection_clear(first=index)
                index = str(int(index)+1)        
                self.lb.selection_set(first=index)
                self.lb.activate(index) 

    def comparison(self):
        pattern = re.compile('.*' + self.var.get() + '.*')
        return [w for w in self.lista if re.match(pattern, w)]

def readValues():
    global amo
    global pro
    global pri
    global qua

    pro=productE.get()
    pri=priceE.get()
    qua=quantityE.get()
    amo=float(pri)*float(qua)
    totalAmount.append(amo)
    ItemsPurchased.append(pro)  #add products to create a single bill
    
def addItem():      #add extra item to the bill
    global num
    global row
    global amountE
    global quantityE
    global priceE
    global productE,Product
    num+=1
    row+=50
    readValues()
    if os.path.isfile('price_list.csv'):
        priceF=pd.read_csv('price_list.csv')
        if str(productE.get()) not in list(priceF['Product']):
            priceF=priceF.append({'Product':str(productE.get()),'Price':str(priceE.get())},ignore_index=True)
    else:
        priceF=pd.DataFrame([[productE.get(),priceE.get()]],columns=['Product','Price'])
    priceF.to_csv('price_list.csv',index=False)
    Product+=str(productE.get())+','
    Price.append(priceE.get())
    productE=tk.Label(root,bg='green',text=str(pro),relief='flat',width=50)
    productE.place(x=330,y=row)
    priceE=tk.Label(root,bg='green',text=str(pri),relief='flat')
    #priceE.grid(column=110,row=row)
    priceE.place(x=550,y=row)
	
    quantityE=tk.Label(root,bg='green',text=str(qua),relief='flat')
    #quantityE.grid(column=120,row=row)
    quantityE.place(x=730,y=row)

    productE.destroy()
    priceE.destroy()
    quantityE.destroy()

    SNo=tk.Label(root,bg='misty rose',text=str(num),font=('Tahoma',18))
    #SNo.grid(column=5,row=row)
    SNo.place(x=170,y=row)
    productE=AutocompleteEntry(listP,root,font=('Tahoma',15),width=10)
    #productE.grid(column=40,row=row)
    productE.place(x=330,y=row)
	
    priceE=tk.Entry(root,relief='flat',font=('Tahoma',15),width=10)
    #priceE.grid(column=110,row=row)
    priceE.place(x=540,y=row)
	
    quantityE=tk.Entry(root,relief='flat',font=('Tahoma',15),width=10)
    #quantityE.grid(column=120,row=row)
    quantityE.place(x=730,y=row)
	
    amountE=tk.Label(root,bg='misty rose',text=str(amo),relief='flat',font=(10))
    #amountE.grid(column=200,row=row-1)
    amountE.place(x=950,y=row-40)
	
    Total=tk.Label(root,bg='misty rose',text="Total Amount:"+str(sum(totalAmount)),fg='Red',font=(30))
    #Total.grid(column=120,row=row+1)
    Total.place(x=850,y=row+40)
    time()
def print_bill():
    p=dataset[4].split(',')[:-1]
    referP=pd.read_csv('price_list.csv')
    if os.path.isfile('print.txt'):
        os.remove('print.txt')
    with open('print.txt','a') as file:
        file.write('\t\tInnovate Yourself\t\t\n')
        file.write('\t\t-----------------------\t\t\n')
        file.write(f'{DT}\t\t\t{q}\n')
        file.write('Product name\t|Price\n')
    for i in p:
        tup=tuple(referP.iloc[list(referP['Product']).index(i),:])
        with open('print.txt','a') as file:
            file.write(f'{tup[0]}\t\t\t{tup[1]}\n')
    with open('print.txt','a') as file:
        file.write(f'Payable Amount:\t{sum(totalAmount)}\n')
    os.startfile("print.txt", "print")  #print bill using printer
    
def Submit():
    dataDict={}
    global dataset
    dataset=[DT,q,nameE.get(),NumberE.get(),Product,sum(totalAmount)]
    for i in columns:
        for j in dataset:
            if columns.index(i)==dataset.index(j):
                dataDict.update({i:str(j)})
    #print(dataDict)
    if os.path.isfile('database.csv'):
        fileD=pd.read_csv('database.csv')
        fileD=fileD.append(dataDict,ignore_index=True)
    else:
        fileD=pd.DataFrame(dataDict,columns=columns,index=[0])
        #fileD.to_csv(filename,index=False)
    #print(fileD)
    fileD.to_csv(filename,index=False)
    #print(dataset)
    top=tk.Toplevel()
    lab=tk.Label(top,text='Submitted Successfully!!!',font=('Arial',15),fg='green')
    lab.pack()
    top.mainloop()
def recommend():
    df=pd.read_csv('database.csv')
    df1=df['Product'].apply(lambda x:x.split(','))
    te = TransactionEncoder()
    te_ary = te.fit(df1).transform(df1)
    df1 = pd.DataFrame(te_ary, columns=te.columns_).drop('',axis=1)
##    print(te.columns_)    
##    print(df1)
    frequent_itemsets = apriori(df1, min_support=0.03, use_colnames=True)
    #sup=sum(frequent_itemsets['support'])*2/len(frequent_itemsets['support'])
    #frequent_itemsets = apriori(df1, min_support=sup, use_colnames=True)
    #print(frequent_itemsets)
    frequent_itemsets['length'] = frequent_itemsets['itemsets'].apply(lambda x: len(x))
    items=frequent_itemsets[ (frequent_itemsets['length'] >= 2) &
                   (frequent_itemsets['support'] >= 0.04) ]
    recP=items['itemsets']
##    win=tk.Tk()
##    win.title('Recommendations for you...')
##    win.geometry('500x500')
##    label=tk.Label(win,text='Recommended products for you...')
##    label.place(x=10,y=10)
##    listbox=tk.Listbox(win,relief='flat',width=50)
##    listbox.place(x=15,y=30)
##    for i in recP:
##        listbox.insert(tk.END,tuple(i))
##    
##    win.mainloop()
    GP=pd.read_csv('price_list.csv')
    class SampleApp(tk.Tk):
        def __init__(self, *args, **kwargs):
            tk.Tk.__init__(self, *args, **kwargs)
            lb = tk.Listbox(self)
            for i in recP:
                lb.insert(tk.END,tuple(i))
            lb.bind("<Double-Button-1>", self.OnDouble)
            lb.pack(side="top", fill="both", expand=True)

        def OnDouble(self, event):
            widget = event.widget
            selection=widget.curselection()
            value = widget.get(selection[0]) 
            
            try:
            
                Rec_pric=(GP.iloc[[list(GP['Product']).index(value[0])],:].values[0][1]+GP.iloc[[list(GP['Product']).index(value[1])],:].values[0][1])-(0.1*(GP.iloc[[list(GP['Product']).index(value[0])],:].values[0][1]+GP.iloc[[list(GP['Product']).index(value[1])],:].values[0][1]))
                img = IMG.new('RGB', (60, 30), color = (0,0,0))
                d = ImageDraw.Draw(img)
                d.text((10,10), "Rs."+str(Rec_pric), fill=(255,255,255))
                img.save('images/recommend_price.png')
                list_file=os.scandir('images')
                item_list=[i.name for i in iter(list_file)]
                first,second='',''
                
                for i in item_list:
                    if str(value[0])==i[:len(str(value[0]))]:
                        first=i
                    if str(value[1])==i[:len(str(value[1]))]:
                        second=i
                #plt.title('Rs.'+str(Rec_pric))
                for j in [first,second,'recommend_price.png']:
                    plt.subplot(1,3,[first,second,'recommend_price.png'].index(j)+1)
                    img=plt.imread('images/'+j)
                    plt.imshow(img)
                    plt.xlabel(j[:-4])
                    plt.xticks([])
                    plt.yticks([])
                    plt.autoscale()
                plt.show()
                #label=tk.Label(roo,text=str(value[0])+'+'+str(value[1])+' = Rs.'+str(int(Rec_pric)),font=('Tahoma',30),fg='white',bg='black')
            
            except:
                  roo=tk.Tk()
                  roo.title('Offer for you...')
                  label=tk.Label(roo,text='Something went wrong!!!',font=('Tahoma',30),fg='white',bg='black')
                  label.pack()
                  roo.mainloop()
            

    if __name__ == "__main__":
        app = SampleApp()
        app.title('Recommended products')
        app.mainloop()



lista=list(set(pd.read_csv('database.csv')['Name']))
listP=list(set(pd.read_csv('price_list.csv')['Product']))
listN=list(set([str(i) for i in pd.read_csv('database.csv')['Mobile Number']]))
#title
heading=Label(root,text='Market Basket Analysis',font=('Tahoma',35,'bold'),fg='Black',bg='misty rose',bd=3)
#heading.grid(column=190,columnspan=8,row=2)
heading.place(x=400,y=1)
#customer Details
nameL=tk.Label(root,bg='misty rose',text='Name',font=('Tahoma',20))
#nameL.grid(column=190,columnspan=2,rowspan=4,row=32)
nameL.place(x=400,y=80)

nameE=AutocompleteEntry(lista,root,font=('Tahoma',20),width=15)
#nameE.grid(column=194,columnspan=4,rowspan=4,row=32)
nameE.place(x=700,y=80)

NumberL=tk.Label(root,bg='misty rose',text='Mobile Number',font=('Tahoma',20))
#NumberL.grid(column=190,columnspan=2,rowspan=4,row=35)
NumberL.place(x=400,y=130)

NumberE=AutocompleteEntry(listN,root,font=('Tahoma',20),width=15)
#NumberE.grid(column=194,columnspan=4,rowspan=4,row=35)
NumberE.place(x=700,y=130)

#today's date and time
time()

#labeling for the product purchase details
SNO=tk.Label(root,bg='misty rose',text='SNo.',font=('Tahoma',20))
SNO.place(x=150,y=240)
product=tk.Label(root,bg='misty rose',text='Product',font=('Tahoma',20))
#product.grid(column=40,row=90)
product.place(x=330,y=240)
price=tk.Label(root,bg='misty rose',text='Price',font=('Tahoma',20))
#price.grid(column=110,row=90)
price.place(x=550,y=240)
quantity=tk.Label(root,bg='misty rose',text='Quantity',font=('Tahoma',20))
#quantity.grid(column=120,row=90)
quantity.place(x=730,y=240)
amount=tk.Label(root,bg='misty rose',text='Amount',font=('Tahoma',20))
#amount.grid(column=200,row=90)
amount.place(x=950,y=240)

#product that is purchased by customer to be entered by the 
SNo=tk.Label(root,bg='misty rose',text=str(num),font=('Tahoma',18))
#SNo.grid(column=5,row=100)
SNo.place(x=170,y=300)
productE=AutocompleteEntry(listP,root,font=('Tahoma',15),width=10)
#productE.grid(column=40,row=100)
productE.place(x=330,y=300)
priceE=tk.Entry(root,font=('Tahoma',15),width=10)
#priceE.grid(column=110,row=100)
priceE.place(x=540,y=300)
quantityE=tk.Entry(root,font=('Tahoma',15),width=10)
#quantityE.grid(column=120,row=100)
quantityE.place(x=730,y=300)
amountE=tk.Label(root,bg='misty rose',relief='flat',font=('Tahoma',20))
#amountE.grid(column=200,row=100)
amountE.place(x=950,y=300)

addButton=tk.Button(root,text='Add+',font=('Tahoma'),width=20,command=addItem,bg='gray',fg='Black',bd=5)
#addButton.grid(column=250,row=36)
addButton.place(x=120,y=650)

SubmitButton=tk.Button(root,text='Submit',font=('Tahoma'),width=20,command=Submit,bg='gray',fg='Black',bd=5)
#SubmitButton.grid(column=250,row=38)
SubmitButton.place(x=400,y=650)

PrintButton=tk.Button(root,text='Print Bill',font=('Tahoma'),width=20,command=print_bill,bg='gray',fg='Black',bd=5)
#PrintButton.grid(column=250,row=40)
PrintButton.place(x=680,y=650)

SubmitButton=tk.Button(root,text='Recommend',font=('Tahoma'),width=20,command=recommend,bg='gray',fg='Black',bd=5)
#SubmitButton.grid(column=250,row=42)
SubmitButton.place(x=960,y=650)

##Total=tk.Label(root,bg='green',text="Total Amount:"+str(sum(totalAmount)))
##Total.grid(column=120,row=52)
root.configure(background='misty rose')
root1.configure(background='misty rose')
root1.mainloop()

